import { Component } from '@angular/core';

@Component({
  selector: 'app-learnerprofile',
  standalone: false,
  
  templateUrl: './learnerprofile.component.html',
  styleUrl: './learnerprofile.component.css'
})
export class LearnerprofileComponent {

}
