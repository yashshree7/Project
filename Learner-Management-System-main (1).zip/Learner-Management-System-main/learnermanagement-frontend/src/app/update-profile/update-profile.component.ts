import { Component } from '@angular/core';

@Component({
  selector: 'app-update-profile',
  standalone: false,
  
  templateUrl: './update-profile.component.html',
  styleUrl: './update-profile.component.css'
})
export class UpdateProfileComponent {

}
