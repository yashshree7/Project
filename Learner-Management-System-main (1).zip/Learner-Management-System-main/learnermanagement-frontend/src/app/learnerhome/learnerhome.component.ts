import { Component } from '@angular/core';

@Component({
  selector: 'app-learnerhome',
  standalone: false,
  
  templateUrl: './learnerhome.component.html',
  styleUrl: './learnerhome.component.css'
})
export class LearnerhomeComponent {

}
