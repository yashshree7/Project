export interface Learner {
    lid?: number ;
    lName: string;
    learnerEmailId: string;
    learnerPassword: string ;
    lphoneNumber:string;
    lDegree:string;
    lpic:string;
}