import { Component } from '@angular/core';

@Component({
  selector: 'app-app-home',
  standalone: false,
  
  templateUrl: './app-home.component.html',
  styleUrl: './app-home.component.css'
})
export class AppHomeComponent {

}
