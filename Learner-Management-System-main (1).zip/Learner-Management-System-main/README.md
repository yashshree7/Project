It is a Learner Management System which can facilitate you to enroll and get information about learners, add those to your wish list, and also manage the entire application.
It has 2 modes of operation as 1) ADMIN 2) LEARNER 
ADMIN Mode 🔭
This mode makes you as an admin and you can perform various activities like...

Adding a Learner
Managing Learners
Add new Learner List 
view Learner List, 

Learner Mode ❤️
This mode makes you as a Learner and you can view your profile after login...

Admin can register for a new account in-order to login to the portal
Check the available Learner List
View & Edit Learner profile details

Technology used: Spring Boot, ORM, Postman, MySQL, Angular JS

Backend Java with Spring Boot: Provides the core functionality, including RESTful API development. Spring Data JPA: Handles database operations using ORM (Object-Relational Mapping).

MySQL: Relational database to store all application data.

Frontend Angular: Frontend framework for building dynamic and responsive user interfaces. HTML/CSS: Used for structuring and styling the web pages.
 
TypeScript: Superset of JavaScript used with Angular for frontend logic.

Tools and Other Technologies Maven: Build automation and dependency management for the Spring Boot application. Node.js & npm: Node.js for running JavaScript outside the browser, npm for managing Angular dependencies. Git: Version control for tracking changes and collaboration. Postman: Used for testing RESTful APIs during development.
